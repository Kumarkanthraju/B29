package stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Login {

	@Given("Login Page is Displayed")
	public void login_page_is_displayed() {
	   System.out.println("Login Page is Displayed");
	}
	

	@When("We enter valid username and password")
	public void we_enter_valid_username_and_password() {
		
	   System.out.println("We enter valid username and password");
	}
	@When("We click on login button")
	public void we_click_on_login_button() {
	  System.out.println("We click on login button");
	}
	
	@Then("Home Page should be displayed")
	public void home_page_should_be_displayed() {
		System.out.println("Home Page should be displayed");
	}
	
	
	@When("We enter invalid username and password")
	public void we_enter_invalid_username_and_password() {
	   System.out.println("We enter invalid username and password");
	}
	@Then("Err message is displayed")
	public void err_message_is_displayed() {
		 System.out.println("Err message is displayed");
	}

}
